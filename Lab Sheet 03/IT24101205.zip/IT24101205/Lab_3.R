setwd("C:\\Users\\it24101205\\Desktop\\IT24101205")

student_data <- read.csv("Exercise.csv")

##Question 1
head(student_data)

#Question 2
summary(student_data$X1)
hist(student_data$X1, main="Histogram of Age", xlab="Age", col="lightblue",border="black")

##Question 3
table(student_data$X2)
barplot(table(student_data$X2),main="Gender Distribution",xlab="Gender",ylab="Count",col=c("pink","lightblue"))

##Question 4
boxplot(X1 ~ X3, data=student_data,
        main="Age vs Accommodation",
        xlab= "Accomadation Type", ylab="Age",
        col=c("lightgreen","lightyellow","lightcoral"))
